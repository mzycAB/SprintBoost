package com.example.sprintboost;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

public class SprintBoostMod implements ModInitializer {
    public static final String MOD_ID = "sprint-boost";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final UUID BOOST_MODIFIER_UUID = UUID.fromString("f5a7c2e4-9b3d-4e1a-8c6f-2d4b7a9e1c05");
    private static final String BOOST_MODIFIER_NAME = "sprint_boost";

    @Override
    public void onInitialize() {
        ServerPlayNetworking.registerGlobalReceiver(BoostPayload.TYPE, (packet, player, responseSender) -> {
            applyBoost(player, packet.multiplier());
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                if (!player.method_5624()) {
                    removeBoost(player);
                }
            }
        });
    }

    private static void applyBoost(class_3222 player, float multiplier) {
        class_1324 instance = player.method_5996(class_5134.field_23719);
        if (instance == null) return;
        instance.method_6200(BOOST_MODIFIER_UUID);
        if (player.method_5624() && multiplier > 1.0f) {
            instance.method_26835(new class_1322(
                    BOOST_MODIFIER_UUID, BOOST_MODIFIER_NAME, multiplier - 1.0, class_1322.class_1323.field_6331));
        }
    }

    private static void removeBoost(class_3222 player) {
        class_1324 instance = player.method_5996(class_5134.field_23719);
        if (instance == null) return;
        instance.method_6200(BOOST_MODIFIER_UUID);
    }
}
