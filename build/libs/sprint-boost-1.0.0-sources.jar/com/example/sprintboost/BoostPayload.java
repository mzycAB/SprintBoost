package com.example.sprintboost;

import net.fabricmc.fabric.api.networking.v1.FabricPacket;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public record BoostPayload(float multiplier) implements FabricPacket {
    public static final PacketType<BoostPayload> TYPE = PacketType.create(
            new class_2960(SprintBoostMod.MOD_ID, "boost"), BoostPayload::new);

    public BoostPayload(class_2540 buf) {
        this(buf.readFloat());
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_52941(this.multiplier);
    }

    @Override
    public PacketType<?> getType() {
        return TYPE;
    }
}
